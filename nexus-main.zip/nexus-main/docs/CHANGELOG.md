<!-- markdownlint-disable MD033 MD041 -->

<a id="top"></a>

# 🕒 Changelog

All notable changes will be documented in this file. The format is based on
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and adheres to
[Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## 📚 Table of Contents

- [🕒 Changelog](#-changelog)
  - [📚 Table of Contents](#-table-of-contents)
  - [📝 Changes](#-changes)

<p align="right"><a href="#top">☝️</a></p>

## 📝 Changes

<!-- Changes will be added here -->

<p align="right"><a href="#top">☝️</a></p>
